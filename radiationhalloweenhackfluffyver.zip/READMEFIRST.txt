-- WARNING!! --

THIS HACK AND STUFF IS NOT CHILD SAFE!! It has a lot of swears in it. But it's appropriate to the season. Let it slide man.

ONLY READ THE MAKING OF AFTER YOU BEAT THE GAME! There's an HTML in there called "The Making of" and if you open it it'll explain everything to you kthxbai.



-- BUGS --

There's one important bug:

- Difficulty is ridiculous

If you get stuck, please consult the attached strategy guide. Thanks.



-- GAME SETTINGS --

Apply the patch to a 3MB, clean EarthBound (U).smc ROM with Lunar IPS. http://fusoya.eludevisibility.org/lips/index.html

Afterward, play with ZSNES. http://www.zsnes.com/

Your sound settings should be 44140hz samples and 8-point filter. That is all.



-- additional thanks --

thanks to Reg for testing and making the Gooberhaunt
thanks to LionRocker for testing and taking screenshots
thanks to JeffMan for testing
thanks to kikiyama for a certain sprite and making Yume Nikki, which inspired me to make this
thanks to Cho-Aniki (the game) for another set of sprites
thanks to Falcom for making the Brandish series, which also inspired me to make this
thanks to Sound Team JDK for composing the Brandish music, which I stole a song from
thanks to the creators of Final Fantasy Legend III for inspiration and a song
thanks to Shigesato Itoi for making the Mother series, which also inspired me to make this
thanks to the creators of Lasagna Cat for making me laugh
thanks to Sebastian, reidman, King Darian, and the other people at the Starmen.net Halloween Funfest
thanks to you for reading this

not for playing

I mean, it's your own fault