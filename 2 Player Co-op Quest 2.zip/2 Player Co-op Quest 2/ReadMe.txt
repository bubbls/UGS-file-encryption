2 Player co-op Quest 2
By Cyphermur9t

--------------------
If you're playing with 2 players, Choose the file 2_Players
If you're playing with 1 player, Choose the file 1_Player

Trust me...

Also, make sure you set your latency to 01 to minimize control lag.

To play with two players you will need zsnes 1.42

Have fun!