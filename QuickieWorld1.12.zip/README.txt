Hey kid, you wanna go fast?

Quickie World is a fast paced Kaizo with very forgiving difficulty. Meant for people who don't want to spend hours grinding out levels, but still want an exciting challenge.
It includes 3 Worlds, 15 Exits, and custom music!

Inspired by games like:

Korosu Mario World
Super Gracie World
Legends of Mario

Here's a list of things you won't find in Quickie World:

Doors
Cutscenes
Kaizo Blocks
Water Levels
Autoscrollers
Ice Physics
Subworlds
Bosses
HUD
Secret Exits
"Trolls"
Switch Palaces

Good luck!

CHANGELOG

1.12
- Fixed potential softlock
- Fixed an overworld oversight (walking right on "Sawrfing Castle")
- Minor graphical improvements
- Last update unless some major break is found. Thanks for playing!

1.11
-Better Retry System
-Fixed music in "Rainbow Road"

1.1 
-Added Retry System
-Minor nerfs in "Tower of Power and Everything is Fine"
-New music in "Rainbow Road"
-New color palette on "Linkdead Shed"
